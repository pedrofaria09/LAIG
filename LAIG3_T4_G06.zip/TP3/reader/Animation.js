function Animation(id, span, type) {
    this.id = id;
    this.span = span;
    this.type = type;
}

Animation.prototype.constructor = Animation;