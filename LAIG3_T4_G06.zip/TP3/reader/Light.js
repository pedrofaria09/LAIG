/**
 * Light
 * @constructor
 */
function Light(id, activated, pos) {
    this.id = id;
    this.activated = activated;
    this.pos = pos;
};